from django.apps import AppConfig


class MkdemoConfig(AppConfig):
    name = 'mdeditor_demo_app'
